from django.apps import AppConfig


class FpConfig(AppConfig):
    name = 'fp'
