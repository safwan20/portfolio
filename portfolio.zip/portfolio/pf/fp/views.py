from django.shortcuts import render
from .models import PROJECTS



def index(request):
    project = PROJECTS.objects.all()
    params = {'project': project}
    return render(request,'index.html',params)


def post(request,id):
    project = PROJECTS.objects.filter(id=id)[0]
    params = {'project': project}
    return render(request,'post.html',params)



