from django.db import models
from datetime import date

class PROJECTS(models.Model) :
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    description = models.TextField(max_length=5000)
    link = models.URLField(
        max_length=128,
        db_index=True,
        unique=True,
        blank=True
    )
    date = models.DateField(default=date.today)
